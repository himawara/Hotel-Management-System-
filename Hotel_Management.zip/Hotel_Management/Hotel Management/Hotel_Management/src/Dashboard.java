import javax.swing.*;
import java.awt.*;

public class Dashboard extends JFrame {
    Dashboard(){
        setBounds(0,0,1550,1000);
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/third.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1550,1000,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0,1550,1000);
        add(image);
        JLabel text = new JLabel("THE TAJ GROUP WELCOMES YOU");
        text.setBounds(400,80,1000,50);
        text.setFont(new Font("Tamoha",Font.PLAIN,45));
        text.setForeground(Color.WHITE);
        image.add(text);
        JMenuBar mb = new JMenuBar();
        mb.setBounds(0,0,1550,30);
        image.add(mb);
        JMenu hotel = new JMenu("Hotel Management");
        hotel.setForeground(Color.RED);
        mb.add(hotel);

        JMenu reception = new JMenu("Reception");
        hotel.add(reception);
        JMenu admin = new JMenu("Hotel Management");
        admin.setForeground(Color.BLUE);
        mb.add(admin);
        JMenuItem addemployee = new JMenuItem("Add Employee");
        admin.add(addemployee);
        JMenuItem adddrivers = new JMenuItem("Add Driver");
        admin.add(adddrivers);
        JMenuItem addrooms = new JMenuItem("Add Room");
        admin.add(addrooms);
        setVisible(true);
    }
    public static void main(String[] args) {
     new Dashboard();

    }
}
