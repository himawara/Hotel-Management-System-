import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Conn {
     Connection conn;
     Statement s;

    public Conn() {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            String url = "jdbc:mysql://localhost:3306/hotelmanagementsystem"; // Ensure this database exists
            String username = "root";
            String password = "W7301@jqir#";

            conn = DriverManager.getConnection(url, username, password);
            s = conn.createStatement(); // Initialize the Statement object
            System.out.println("Database connection established successfully.");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Failed to connect to the database.");
            e.printStackTrace();
        }
    }

    public Connection getConnection() {
        return conn;
    }

    public Statement getStatement() {
        return s;
    }

    // Method to close the database resources
    public void close() {
        try {
            if (s != null && !s.isClosed()) {
                s.close(); // Close Statement
            }
            if (conn != null && !conn.isClosed()) {
                conn.close(); // Close Connection
            }
            System.out.println("Database resources closed successfully.");
        } catch (SQLException e) {
            System.err.println("Error while closing database resources.");
            e.printStackTrace();
        }
    }
}
