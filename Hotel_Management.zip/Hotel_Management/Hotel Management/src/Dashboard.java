import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Dashboard extends JFrame implements ActionListener {

    JMenuItem addEmployeeItem, addRoomsItem, addDriversItem, receptionItem;

    public static void main(String[] args) {
        new Dashboard().setVisible(true);
    }

    public Dashboard() {
        super("HOTEL MANAGEMENT SYSTEM");

        setForeground(Color.CYAN);
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/third.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1950, 1000, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel NewLabel = new JLabel(i3);
        NewLabel.setBounds(0, 0, 1950, 1000);
        add(NewLabel);

        JLabel hotelWelcomeLabel = new JLabel("THE TAJ GROUP WELCOMES YOU");
        hotelWelcomeLabel.setForeground(Color.WHITE);
        hotelWelcomeLabel.setFont(new Font("Tahoma", Font.PLAIN, 46));
        hotelWelcomeLabel.setBounds(600, 60, 1000, 85);
        NewLabel.add(hotelWelcomeLabel);

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        JMenu hotelManagementMenu = new JMenu("HOTEL MANAGEMENT");
        hotelManagementMenu.setForeground(Color.BLUE);
        menuBar.add(hotelManagementMenu);

        receptionItem = new JMenuItem("RECEPTION"); // Define receptionItem here
        receptionItem.addActionListener(this); // Attach ActionListener to receptionItem
        hotelManagementMenu.add(receptionItem);

        JMenu adminMenu = new JMenu("ADMIN");
        adminMenu.setForeground(Color.RED);
        menuBar.add(adminMenu);

        addEmployeeItem = new JMenuItem("ADD EMPLOYEE");
        adminMenu.add(addEmployeeItem);
        addEmployeeItem.addActionListener(this);

        addRoomsItem = new JMenuItem("ADD ROOMS");
        adminMenu.add(addRoomsItem);
        addRoomsItem.addActionListener(this);

        addDriversItem = new JMenuItem("ADD DRIVERS");
        adminMenu.add(addDriversItem);
        addDriversItem.addActionListener(this);

        setSize(1950, 1090);
        setVisible(true);
        getContentPane().setBackground(Color.WHITE);
    }

    // ActionListener method
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == addEmployeeItem) {
            new AddEmployee().setVisible(true);
        } else if (ae.getSource() == addRoomsItem) {
            new AddRoom().setVisible(true);
        } else if (ae.getSource() == addDriversItem) {
            new AddDrivers().setVisible(true);
        } else if (ae.getSource() == receptionItem) { // Add condition for receptionItem
            new Reception().setVisible(true);
        }
    }
}
