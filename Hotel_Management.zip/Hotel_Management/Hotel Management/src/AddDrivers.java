import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class AddDrivers extends JFrame {
    private JTextField nameField, ageField, companyField, brandField, locationField;
    private JComboBox<String> genderCombo, availableCombo;

    public AddDrivers() {
        setTitle("ADD DRIVER DETAILS");
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setSize(900, 600);
        getContentPane().setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        // Header Label
        JLabel headerLabel = new JLabel("ADD DRIVER DETAILS");
        headerLabel.setForeground(Color.BLUE);
        headerLabel.setFont(new Font("Tahoma", Font.PLAIN, 31));
        headerLabel.setBounds(300, 20, 400, 40);
        add(headerLabel);

        // Name Field
        JLabel nameLabel = new JLabel("NAME");
        nameLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
        nameLabel.setBounds(60, 80, 150, 27);
        add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(200, 80, 150, 27);
        add(nameField);

        // Age Field
        JLabel ageLabel = new JLabel("AGE");
        ageLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
        ageLabel.setBounds(60, 120, 150, 27);
        add(ageLabel);

        ageField = new JTextField();
        ageField.setBounds(200, 120, 150, 27);
        add(ageField);

        // Gender Combo Box
        JLabel genderLabel = new JLabel("GENDER");
        genderLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
        genderLabel.setBounds(60, 160, 150, 27);
        add(genderLabel);

        genderCombo = new JComboBox<>(new String[]{"Male", "Female"});
        genderCombo.setBackground(Color.WHITE);
        genderCombo.setBounds(200, 160, 150, 27);
        add(genderCombo);

        // Car Company Field
        JLabel companyLabel = new JLabel("CAR COMPANY");
        companyLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
        companyLabel.setBounds(60, 200, 150, 27);
        add(companyLabel);

        companyField = new JTextField();
        companyField.setBounds(200, 200, 150, 27);
        add(companyField);

        // Car Brand Field
        JLabel brandLabel = new JLabel("CAR BRAND");
        brandLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
        brandLabel.setBounds(60, 240, 150, 27);
        add(brandLabel);

        brandField = new JTextField();
        brandField.setBounds(200, 240, 150, 27);
        add(brandField);

        // Available Combo Box
        JLabel availableLabel = new JLabel("AVAILABLE");
        availableLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
        availableLabel.setBounds(60, 280, 150, 27);
        add(availableLabel);

        availableCombo = new JComboBox<>(new String[]{"Yes", "No"});
        availableCombo.setBackground(Color.WHITE);
        availableCombo.setBounds(200, 280, 150, 27);
        add(availableCombo);

        // Location Field
        JLabel locationLabel = new JLabel("LOCATION");
        locationLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
        locationLabel.setBounds(60, 320, 150, 27);
        add(locationLabel);

        locationField = new JTextField();
        locationField.setBounds(200, 320, 150, 27);
        add(locationField);

        // Save Button
        JButton saveButton = new JButton("SAVE");
        saveButton.setBounds(200, 380, 150, 30);
        saveButton.setBackground(Color.BLACK);
        saveButton.setForeground(Color.WHITE);
        add(saveButton);

        // Background Image
        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icons/eleven.jpg"));
        Image image = imageIcon.getImage().getScaledInstance(500, 500, Image.SCALE_DEFAULT);
        JLabel imageLabel = new JLabel(new ImageIcon(image));
        imageLabel.setBounds(410, 80, 480, 410);
        add(imageLabel);

        // Save Button Action Listener
        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                String name = nameField.getText();
                String age = ageField.getText();
                String gender = (String) genderCombo.getSelectedItem();
                String company = companyField.getText();
                String brand = brandField.getText();
                String available = (String) availableCombo.getSelectedItem();
                String location = locationField.getText();

                try {
                    Conn c = new Conn();
                    String str = "insert into driver (name, age, gender, company, branch, available, location) " +
                            "VALUES ('" + name + "', '" + age + "', '" + gender + "', '" + company + "', '" +
                            brand + "', '" + available + "', '" + location + "')";

                    int result = c.s.executeUpdate(str);
                    if (result > 0) {
                        JOptionPane.showMessageDialog(null, "Driver Added Successfully");
                    } else {
                        JOptionPane.showMessageDialog(null, "Failed to Add Driver");
                    }
                    setVisible(false);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        });

        setLocation(530, 200);
        setVisible(true);
    }

    public static void main(String[] args) {
        new AddDrivers();
    }
}
